import subprocess
import tempfile
import os
import re
import datetime

def detect_language(code):
    """Attempt to detect the programming language from code"""
    # Check for common language indicators
    if re.search(r"^import\s+[a-zA-Z0-9_.]+|^from\s+[a-zA-Z0-9_.]+\s+import", code, re.MULTILINE):
        return "python"
    elif re.search(r"<html|<head|<body|<script|<div", code, re.IGNORECASE):
        return "html"
    elif re.search(r"function\s+\w+\s*\(|const\s+\w+\s*=|let\s+\w+\s*=|var\s+\w+\s*=|=>", code):
        return "javascript"
    elif re.search(r"#include\s+<\w+\.h>|int\s+main\s*\(", code):
        return "c"
    elif re.search(r"public\s+class|public\s+static\s+void\s+main", code):
        return "java"
    else:
        return "unknown"

def format_code(code, language):
    """Format code based on language"""
    if language == "python":
        try:
            # Simple indentation fix for Python
            lines = code.split('\n')
            formatted_lines = []
            indent_level = 0
            for line in lines:
                stripped = line.strip()
                
                # Adjust indent level based on code structure
                if stripped.endswith(':'):
                    formatted_lines.append('    ' * indent_level + stripped)
                    indent_level += 1
                elif stripped.startswith('return ') or stripped in ['break', 'continue', 'pass']:
                    formatted_lines.append('    ' * max(0, indent_level - 1) + stripped)
                elif stripped.startswith(('elif ', 'else:', 'except:', 'finally:')):
                    indent_level = max(0, indent_level - 1)
                    formatted_lines.append('    ' * indent_level + stripped)
                    if stripped.endswith(':'):
                        indent_level += 1
                else:
                    formatted_lines.append('    ' * indent_level + stripped)
                    
            return '\n'.join(formatted_lines)
        except Exception:
            return code
    else:
        # Return original code for other languages
        return code

def execute_code(code, language=None):
    """Execute the provided code and return the output"""
    if not language or language == "text":
        language = detect_language(code)
    
    if language == "python":
        return execute_python(code)
    elif language in ["javascript", "js"]:
        return execute_javascript(code)
    elif language in ["bash", "shell", "sh"]:
        return execute_bash(code)
    else:
        return f"Execution not supported for {language}"

def execute_python(code):
    """Execute Python code and return the output"""
    try:
        with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp:
            temp.write(code.encode('utf-8'))
            temp_path = temp.name
        
        # Run the code with a timeout
        result = subprocess.run(
            ['python', temp_path],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        # Clean up the temporary file
        os.unlink(temp_path)
        
        # Return stderr if there's an error, otherwise stdout
        if result.returncode != 0:
            return f"Error:\n{result.stderr}"
        return result.stdout
    
    except subprocess.TimeoutExpired:
        return "Execution timed out (limit: 10 seconds)"
    except Exception as e:
        return f"Execution error: {str(e)}"

def execute_javascript(code):
    """Execute JavaScript code using Node.js and return the output"""
    try:
        with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as temp:
            temp.write(code.encode('utf-8'))
            temp_path = temp.name
        
        # Run the code with a timeout
        result = subprocess.run(
            ['node', temp_path],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        # Clean up the temporary file
        os.unlink(temp_path)
        
        # Return stderr if there's an error, otherwise stdout
        if result.returncode != 0:
            return f"Error:\n{result.stderr}"
        return result.stdout
    
    except subprocess.TimeoutExpired:
        return "Execution timed out (limit: 10 seconds)"
    except Exception as e:
        return f"Execution error: {str(e)}"

def execute_bash(code):
    """Execute Bash code and return the output"""
    try:
        with tempfile.NamedTemporaryFile(suffix='.sh', delete=False) as temp:
            temp.write(code.encode('utf-8'))
            temp_path = temp.name
        
        # Make the script executable
        os.chmod(temp_path, 0o755)
        
        # Run the code with a timeout
        result = subprocess.run(
            ['/bin/bash', temp_path],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        # Clean up the temporary file
        os.unlink(temp_path)
        
        # Return stderr if there's an error, otherwise stdout
        if result.returncode != 0:
            return f"Error:\n{result.stderr}"
        return result.stdout
    
    except subprocess.TimeoutExpired:
        return "Execution timed out (limit: 10 seconds)"
    except Exception as e:
        return f"Execution error: {str(e)}"

def save_code_to_file(code, filename, language=None):
    """Save the code to a file with the appropriate extension"""
    # Detect language if not provided
    if not language or language == "text":
        language = detect_language(code)
    
    # Map language to file extension
    extensions = {
        "python": ".py",
        "javascript": ".js",
        "js": ".js",
        "html": ".html",
        "css": ".css",
        "bash": ".sh",
        "shell": ".sh",
        "sh": ".sh",
        "c": ".c",
        "cpp": ".cpp",
        "java": ".java",
        "unknown": ".txt"
    }
    
    # Get the appropriate extension
    ext = extensions.get(language.lower(), ".txt")
    
    # Clean the filename
    base_filename = os.path.basename(filename)
    base_filename = re.sub(r'[^\w\-\.]', '_', base_filename)
    
    # Add extension if not present
    if not base_filename.endswith(ext):
        if "." in base_filename:
            base_filename = os.path.splitext(base_filename)[0] + ext
        else:
            base_filename = base_filename + ext
    
    # Create a timestamp for uniqueness
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Create 'generated_code' directory if it doesn't exist
    code_dir = "generated_code"
    if not os.path.exists(code_dir):
        os.makedirs(code_dir)
    
    # Create the full filepath
    filepath = os.path.join(code_dir, f"{timestamp}_{base_filename}")
    
    # Save the code to the file
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(code)
        return {"success": True, "filepath": filepath}
    except Exception as e:
        return {"success": False, "error": str(e)}

def get_language_options():
    """Return a list of supported programming languages with descriptions"""
    return [
        {"id": "python", "name": "Python", "description": "General-purpose, high-level programming language"},
        {"id": "javascript", "name": "JavaScript", "description": "Programming language for web development"},
        {"id": "html", "name": "HTML", "description": "Markup language for web pages"},
        {"id": "css", "name": "CSS", "description": "Style sheet language for web pages"},
        {"id": "bash", "name": "Bash", "description": "Unix shell and command language"},
        {"id": "c", "name": "C", "description": "General-purpose, procedural programming language"},
        {"id": "cpp", "name": "C++", "description": "General-purpose programming language with OOP features"},
        {"id": "java", "name": "Java", "description": "Class-based, object-oriented programming language"}
    ]
