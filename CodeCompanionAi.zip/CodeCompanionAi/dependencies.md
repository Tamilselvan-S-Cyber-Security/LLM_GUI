# Dependencies for Tamizh Hacker AI Coding Assistant

## Required Packages
```
streamlit>=1.24.0
requests>=2.28.1
gTTS>=2.3.1
```

## Installation
The following packages should be installed to run the application:

1. **streamlit**: For creating the web interface
   ```
   pip install streamlit
   ```

2. **requests**: For making API calls to Ollama
   ```
   pip install requests
   ```

3. **gTTS** (Google Text-to-Speech): For speech functionality
   ```
   pip install gTTS
   ```

## Using with Replit
In Replit, use the package manager to install dependencies instead of directly editing the requirements.txt file:

1. Click on the "Packages" icon in the sidebar
2. Search for each package and install them:
   - streamlit
   - requests
   - gTTS

## Using with Poetry
If you're using Poetry for dependency management:

```bash
poetry add streamlit requests gTTS
```

## Using with Conda
If you're using Conda for environment management:

```bash
conda install -c conda-forge streamlit requests
pip install gTTS
```

Note: When deploying to a different environment, make sure to install these dependencies before running the application.