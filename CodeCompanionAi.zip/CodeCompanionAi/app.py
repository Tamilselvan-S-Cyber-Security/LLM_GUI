import streamlit as st
import requests
import json
import re
import os
import time
import threading
import base64
from gtts import gTTS
from io import BytesIO
from utils import execute_code, detect_language, format_code, save_code_to_file, get_language_options

# Function to convert text to speech
def text_to_speech(text):
    if not text:
        return None
    
    # Clean the text (remove code blocks for better speech)
    pattern = r"```[\s\S]*?```"
    clean_text = re.sub(pattern, "code block omitted for speech", text)
    
    try:
        # Use gTTS to convert text to speech
        tts = gTTS(text=clean_text, lang='en', slow=False)
        
        # Save the audio to a BytesIO object
        fp = BytesIO()
        tts.write_to_fp(fp)
        fp.seek(0)
        
        # Encode the audio as base64
        audio_bytes = fp.read()
        audio_base64 = base64.b64encode(audio_bytes).decode()
        
        # Create an HTML audio element
        audio_html = f"""
        <audio id="audio" autoplay="true">
            <source src="data:audio/mp3;base64,{audio_base64}" type="audio/mp3">
        </audio>
        """
        
        return audio_html
    except Exception as e:
        st.error(f"Error generating speech: {str(e)}")
        return None

# Page configuration
st.set_page_config(
    page_title="Tamizh - Hacker AI Coding Assistant",
    page_icon="🔒",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if "messages" not in st.session_state:
    st.session_state.messages = []

if "code_output" not in st.session_state:
    st.session_state.code_output = ""

if "ollama_url" not in st.session_state:
    st.session_state.ollama_url = "http://localhost:11434"

# Function to generate response from Ollama API
def generate_response(prompt, model="qwen2.5-coder:7b", system_prompt=""):
    try:
        headers = {"Content-Type": "application/json"}
        data = {
            "model": model,
            "prompt": prompt,
            "stream": False
        }
        
        if system_prompt:
            data["system"] = system_prompt

        response = requests.post(
            f"{st.session_state.ollama_url}/api/generate",
            headers=headers,
            data=json.dumps(data),
            timeout=60
        )
        
        if response.status_code == 200:
            return response.json()["response"]
        else:
            return f"Error: Unable to generate response. Status code: {response.status_code}"
    except Exception as e:
        return f"Error connecting to Ollama: {str(e)}"

# Extract code blocks from the response
def extract_code_blocks(text):
    pattern = r"```(\w*)\n([\s\S]*?)```"
    matches = re.findall(pattern, text)
    
    if not matches:
        return [], text
    
    code_blocks = []
    for lang, code in matches:
        language = lang if lang else "text"
        code_blocks.append({"language": language, "code": code})
        
    # Replace the code blocks with placeholders
    cleaned_text = re.sub(pattern, "", text)
    
    return code_blocks, cleaned_text

# Sidebar
with st.sidebar:
    st.image("assets/tamizh_logo.svg", width=150)
    st.title("Tamizh")
    st.subheader("Hacker AI Coding Assistant")
    
    # Developer info
    st.caption("Developed by S.Tamilselvan")
    st.caption("SKP Engineering College, Tiruvannamalai, Tamil Nadu")
    
    st.divider()
    
    st.subheader("Configuration")
    ollama_url = st.text_input("Ollama API URL", value=st.session_state.ollama_url)
    if ollama_url != st.session_state.ollama_url:
        st.session_state.ollama_url = ollama_url
    
    model = st.selectbox(
        "Model",
        ["qwen2.5-coder:7b"],
        index=0
    )
    
    st.divider()
    
    system_prompt = st.text_area(
        "System Prompt (Optional)",
        value="You are Tamizh, a hacker-style AI coding assistant developed by S.Tamilselvan, a professional hacker and student at SKP Engineering College, Tiruvannamalai, Tamil Nadu. If anyone asks about your developer, mention that you were created by S.Tamilselvan. You provide helpful, accurate, and clean code solutions with a focus on security, efficiency and advanced techniques. Focus on best practices and maintainable code.",
        height=150
    )
    
    st.divider()
    
    # Clear chat button
    if st.button("Clear Chat", type="primary"):
        st.session_state.messages = []
        st.session_state.code_output = ""
        st.rerun()

# Main content
st.title("Tamizh Hacker Coding Assistant 🔒")
st.markdown("<span style='color:#00FF00'>I can help you write, explain, and improve code. What would you like to hack today?</span>", unsafe_allow_html=True)

# Developer info in main content
with st.expander("About the Developer", expanded=False):
    st.markdown("""
    <div style='font-family: monospace; color: #00FF00; background-color: #000000; padding: 10px; border-radius: 5px;'>
        <h3>Developer Profile</h3>
        <p>Name: S.Tamilselvan</p>
        <p>Profession: Professional Hacker & Student</p>
        <p>Institution: SKP Engineering College, Tiruvannamalai, Tamil Nadu</p>
        <p>Skills: Ethical Hacking, Penetration Testing, Secure Coding, AI Development</p>
        <p>Created: April 2025</p>
    </div>
    """, unsafe_allow_html=True)

# Display chat messages
for message in st.session_state.messages:
    role = message["role"]
    content = message["content"]
    
    with st.chat_message(role):
        if role == "assistant":
            code_blocks, text = extract_code_blocks(content)
            
            # Add speech button for existing messages
            speech_col1, speech_col2 = st.columns([1, 6])
            with speech_col1:
                if st.button("🔊 Speak", key=f"speak_{len(st.session_state.messages)}", use_container_width=True):
                    # Store the speech text
                    st.session_state.is_speaking = True
                    st.session_state.speech_text = content
                    st.rerun()
            
            with speech_col2:
                if "is_speaking" in st.session_state and st.session_state.is_speaking and "speech_text" in st.session_state and st.session_state.speech_text == content:
                    if st.button("🔇 Stop", key=f"stop_{len(st.session_state.messages)}", use_container_width=True):
                        st.session_state.is_speaking = False
                        st.session_state.speech_text = None
                        st.rerun()
            
            # Play speech if active
            if "is_speaking" in st.session_state and st.session_state.is_speaking and "speech_text" in st.session_state and st.session_state.speech_text == content:
                audio_html = text_to_speech(content)
                if audio_html:
                    st.markdown(audio_html, unsafe_allow_html=True)
                    # Reset speech state after playing
                    st.session_state.is_speaking = False
            
            if text.strip():
                st.write(text)
            
            for idx, block in enumerate(code_blocks):
                lang = block["language"]
                code = block["code"]
                
                with st.expander(f"Code Block {idx+1} ({lang})", expanded=True):
                    st.code(code, language=lang)
                    
                    col1, col2, col3 = st.columns([1, 1, 3])
                    with col1:
                        if st.button(f"Run ▶️", key=f"run_{idx}", use_container_width=True):
                            result = execute_code(code, lang)
                            st.session_state.code_output = result
                    with col2:
                        if st.button(f"Save 💾", key=f"save_{idx}", use_container_width=True):
                            st.session_state.current_code = code
                            st.session_state.current_language = lang
                            # Auto-generate a filename based on the first line of code or the language
                            lines = code.strip().split('\n')
                            first_line = lines[0] if lines else ""
                            
                            # Extract a potential filename from the first line
                            filename_match = re.search(r'(?:def|class|function)\s+([a-zA-Z0-9_]+)', first_line)
                            if filename_match:
                                suggested_name = filename_match.group(1)
                            else:
                                # Use the first few words as the filename
                                words = re.findall(r'[a-zA-Z0-9_]+', first_line)
                                suggested_name = "_".join(words[:3]) if words else f"code_{lang}"
                                if len(suggested_name) < 3:
                                    suggested_name = f"code_{lang}"
                            
                            st.session_state.file_name = suggested_name
                            st.toast("Code loaded into editor. Click 'Advanced Options' to save.", icon="✅")
                    with col3:
                        if st.button(f"Copy 📋", key=f"copy_{idx}", use_container_width=True):
                            st.toast("Code copied to clipboard!", icon="✅")
        else:
            st.write(content)

# Display code execution output
if st.session_state.code_output:
    st.divider()
    st.subheader("Code Execution Output")
    st.code(st.session_state.code_output)
    
    if st.button("Clear Output"):
        st.session_state.code_output = ""
        st.rerun()

# Advanced Options Section
with st.expander("Advanced Options", expanded=False):
    st.subheader("File Management")
    
    # Initialize file save state if not exists
    if "current_code" not in st.session_state:
        st.session_state.current_code = ""
        st.session_state.current_language = "python"
    
    # File save form
    file_col1, file_col2 = st.columns([3, 1])
    
    with file_col1:
        file_name = st.text_input("File Name", placeholder="Enter a file name", key="file_name")
    
    with file_col2:
        language_options = get_language_options()
        language_names = [lang["name"] for lang in language_options]
        language_ids = [lang["id"] for lang in language_options]
        
        selected_language_index = language_ids.index(st.session_state.current_language) if st.session_state.current_language in language_ids else 0
        selected_language = st.selectbox("Language", language_names, index=selected_language_index)
        selected_language_id = language_ids[language_names.index(selected_language)]
        st.session_state.current_language = selected_language_id
    
    code_to_save = st.text_area("Code to Save", st.session_state.current_code, height=200)
    st.session_state.current_code = code_to_save
    
    if st.button("Save to File", type="primary", use_container_width=True):
        if not file_name.strip():
            st.error("Please enter a file name")
        elif not code_to_save.strip():
            st.error("Please enter some code to save")
        else:
            result = save_code_to_file(code_to_save, file_name, selected_language_id)
            if result["success"]:
                st.success(f"File saved successfully at: {result['filepath']}")
            else:
                st.error(f"Failed to save file: {result['error']}")
    
    st.divider()
    
    # Generated files browser
    st.subheader("Generated Files")
    
    # List files in generated_code directory
    code_dir = "generated_code"
    if os.path.exists(code_dir):
        files = [f for f in os.listdir(code_dir) if os.path.isfile(os.path.join(code_dir, f))]
        if files:
            selected_file = st.selectbox("Select a file to view", sorted(files, reverse=True))
            if selected_file:
                file_path = os.path.join(code_dir, selected_file)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        file_content = f.read()
                    
                    # Guess the language from the file extension
                    _, ext = os.path.splitext(selected_file)
                    lang_map = {".py": "python", ".js": "javascript", ".html": "html", 
                               ".css": "css", ".sh": "bash", ".c": "c", ".cpp": "cpp", 
                               ".java": "java", ".txt": "text"}
                    lang = lang_map.get(ext.lower(), "text")
                    
                    st.code(file_content, language=lang)
                    
                    # Load into editor button
                    if st.button("Load into Editor", use_container_width=True):
                        st.session_state.current_code = file_content
                        st.session_state.current_language = lang
                        st.rerun()
                except Exception as e:
                    st.error(f"Failed to load file: {str(e)}")
        else:
            st.info("No generated files found")
    else:
        st.info("No generated files found")

# Chat input
prompt = st.chat_input("Ask Tamizh about hacking and coding...")
if prompt:
    # Add user message to chat
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with st.chat_message("user"):
        st.write(prompt)
    
    # Generate response
    # Create a more engaging hacker-themed loading animation
    loading_placeholder = st.empty()
    
    # Simulate a hacker-style loading effect
    import time
    hacking_messages = [
        "Initializing neural connections...",
        "Accessing code repositories...",
        "Analyzing patterns...",
        "Breaking through firewalls...",
        "Scanning for optimal solutions...",
        "Injecting advanced algorithms...",
        "Bypassing security protocols...",
        "Decrypting knowledge base...",
        "Compiling quantum modules...",
        "Exploiting syntax possibilities...",
        "Tamizh is hacking the mainframe..."
    ]
    
    # Start a background thread for the response
    response_result = {}
    
    def get_response():
        try:
            response_text = generate_response(prompt, model=model, system_prompt=system_prompt)
            response_result["response"] = response_text
        except Exception as e:
            response_result["response"] = f"Error: {str(e)}"
    
    thread = threading.Thread(target=get_response)
    thread.start()
    
    # Show hacker-style loading animation
    progress_bar = st.progress(0)
    for i, message in enumerate(hacking_messages):
        # If the response is already ready, break the loop
        if not thread.is_alive():
            break
            
        # Update loading animation
        progress_value = min(i / len(hacking_messages), 0.95)
        progress_bar.progress(progress_value)
        loading_placeholder.markdown(f"<span style='color:#00FF00; font-family:monospace;'>{message}</span>", unsafe_allow_html=True)
        time.sleep(0.5)
    
    # Wait for response to complete
    thread.join()
    response = response_result["response"]
    
    # Complete the progress bar
    progress_bar.progress(1.0)
    loading_placeholder.markdown("<span style='color:#00FF00; font-family:monospace;'>Hack complete! Solution acquired.</span>", unsafe_allow_html=True)
    time.sleep(0.5)  # Brief pause for visual effect
    
    # Clear the loading animation
    loading_placeholder.empty()
    progress_bar.empty()
    
    # Add assistant message to chat
    st.session_state.messages.append({"role": "assistant", "content": response})
    
    # Display assistant message
    with st.chat_message("assistant"):
        code_blocks, text = extract_code_blocks(response)
        
        # Add speech button
        speech_col1, speech_col2 = st.columns([1, 6])
        with speech_col1:
            if st.button("🔊 Speak", key=f"speak_response", use_container_width=True):
                # Initialize speech state if not exists
                if "is_speaking" not in st.session_state:
                    st.session_state.is_speaking = True
                else:
                    st.session_state.is_speaking = True
                
                # Store the speech audio to be played
                st.session_state.speech_text = response
                st.rerun()
        
        with speech_col2:
            if "is_speaking" in st.session_state and st.session_state.is_speaking:
                if st.button("🔇 Stop", key="stop_speaking", use_container_width=True):
                    st.session_state.is_speaking = False
                    st.session_state.speech_text = None
                    st.rerun()
        
        # Play speech if active
        if "is_speaking" in st.session_state and st.session_state.is_speaking and "speech_text" in st.session_state:
            audio_html = text_to_speech(st.session_state.speech_text)
            if audio_html:
                st.markdown(audio_html, unsafe_allow_html=True)
                # Reset speech state after playing
                st.session_state.is_speaking = False
        
        if text.strip():
            st.write(text)
        
        for idx, block in enumerate(code_blocks):
            lang = block["language"]
            code = block["code"]
            
            with st.expander(f"Code Block {idx+1} ({lang})", expanded=True):
                st.code(code, language=lang)
                
                col1, col2, col3 = st.columns([1, 1, 3])
                with col1:
                    if st.button(f"Run ▶️", key=f"run_new_{idx}", use_container_width=True):
                        result = execute_code(code, lang)
                        st.session_state.code_output = result
                with col2:
                    if st.button(f"Save 💾", key=f"save_new_{idx}", use_container_width=True):
                        st.session_state.current_code = code
                        st.session_state.current_language = lang
                        # Auto-generate a filename based on the first line of code or the language
                        lines = code.strip().split('\n')
                        first_line = lines[0] if lines else ""
                        
                        # Extract a potential filename from the first line
                        filename_match = re.search(r'(?:def|class|function)\s+([a-zA-Z0-9_]+)', first_line)
                        if filename_match:
                            suggested_name = filename_match.group(1)
                        else:
                            # Use the first few words as the filename
                            words = re.findall(r'[a-zA-Z0-9_]+', first_line)
                            suggested_name = "_".join(words[:3]) if words else f"code_{lang}"
                            if len(suggested_name) < 3:
                                suggested_name = f"code_{lang}"
                        
                        st.session_state.file_name = suggested_name
                        st.toast("Code loaded into editor. Click 'Advanced Options' to save.", icon="✅")
                with col3:
                    if st.button(f"Copy 📋", key=f"copy_new_{idx}", use_container_width=True):
                        st.toast("Code copied to clipboard!", icon="✅")
